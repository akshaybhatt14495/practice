package ratelimitter.models;


import ratelimitter.models.TimeConstants;

public enum TimeEnum {
    SECOND(TimeConstants.second, false),
    Minute(TimeConstants.minute/6, true),
    HOUR(TimeConstants.hour, true),
    DAY(TimeConstants.day, true),
    WEEK(TimeConstants.week, true),
    MONTH(TimeConstants.month, true);

    public final int intervalInSec;
    public final boolean enable;

    private TimeEnum(int intervalInSec,  boolean enable) {
        this.intervalInSec = intervalInSec;
        this.enable = enable;
    }
}
